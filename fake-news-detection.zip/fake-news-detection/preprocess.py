import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.feature_extraction.text import TfidfVectorizer
import joblib

def load_and_preprocess(csv_path, test_size=0.2, random_state=42):
    df = pd.read_csv(csv_path)
    X = df['text']
    y = df['label']
    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=test_size, random_state=random_state)
    vect = TfidfVectorizer(stop_words='english', max_df=0.7)
    X_train_tfidf = vect.fit_transform(X_train)
    X_test_tfidf = vect.transform(X_test)
    joblib.dump(vect, 'vect.pkl')
    return X_train_tfidf, X_test_tfidf, y_train, y_test
