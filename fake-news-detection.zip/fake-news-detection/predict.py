import joblib
import tensorflow as tf

def load_model_and_vectorizer():
    vect = joblib.load('vect.pkl')
    model = tf.keras.models.load_model('fake_news_model.h5')
    return vect, model

def predict_text(text):
    vect, model = load_model_and_vectorizer()
    X = vect.transform([text])
    pred = model.predict(X.toarray())
    return 'Fake' if pred[0][0] > 0.5 else 'Real'

if __name__ == '__main__':
    sample = input("Enter news text: ")
    print("Prediction:", predict_text(sample))
