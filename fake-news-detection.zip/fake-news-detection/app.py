from flask import Flask, request, render_template
from predict import predict_text

app = Flask(__name__)

@app.route('/', methods=['GET', 'POST'])
def home():
    result = None
    text = ""
    if request.method == 'POST':
        text = request.form['news_text']
        result = predict_text(text)
    return render_template('index.html', result=result, text=text)

if __name__ == '__main__':
    app.run(debug=True)
