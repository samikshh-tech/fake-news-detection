import tensorflow as tf
from sklearn.metrics import accuracy_score, confusion_matrix
from preprocess import load_and_preprocess
import joblib

def build_model(input_dim):
    model = tf.keras.Sequential([
        tf.keras.layers.InputLayer(input_shape=(input_dim,)),
        tf.keras.layers.Dense(512, activation='relu'),
        tf.keras.layers.Dropout(0.5),
        tf.keras.layers.Dense(1, activation='sigmoid')
    ])
    model.compile(loss='binary_crossentropy', optimizer='adam', metrics=['accuracy'])
    return model

def train_and_save(data_csv):
    X_train, X_test, y_train, y_test = load_and_preprocess(data_csv)
    model = build_model(X_train.shape[1])
    model.fit(X_train.toarray(), y_train, epochs=5, batch_size=64, validation_split=0.1)
    preds = (model.predict(X_test.toarray()) > 0.5).astype(int)
    print("Accuracy:", accuracy_score(y_test, preds))
    print("Confusion Matrix:\n", confusion_matrix(y_test, preds))
    model.save('fake_news_model.h5')

if __name__ == '__main__':
    train_and_save('data/fake_or_real_news.csv')
